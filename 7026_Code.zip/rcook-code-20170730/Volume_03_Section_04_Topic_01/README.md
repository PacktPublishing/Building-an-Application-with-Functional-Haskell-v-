# Building an Application with Haskell

## 3.4.1 "Reading items"

### Build `step-013`

```
cd step-013
stack build
stack exec to-do-exe
```

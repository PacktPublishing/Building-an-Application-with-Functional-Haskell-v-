# Building an Application with Haskell

## 3.4.5 "Displaying our to-do list"

### Build `step-017`

```
cd step-017
stack build
stack exec to-do-exe
```

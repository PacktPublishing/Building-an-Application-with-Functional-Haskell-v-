# Building an Application with Haskell

## 3.4.4 "Updating items"

### Build `step-016`

```
cd step-016
stack build
stack exec to-do-exe
```

# Building an Application with Haskell

## 3.4.6 "Other commands"

### Build `step-018`

```
cd step-018
stack build
stack exec to-do-exe
```

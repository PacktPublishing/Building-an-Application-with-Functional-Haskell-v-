# Building an Application with Haskell

## 3.2.3 "Subparsers and wrapping up"

### Build `step-005`

```
cd step-005
stack build
stack exec to-do-exe
```

### Build `step-006`

```
cd step-006
stack build
stack exec to-do-exe
```

### Build `step-007`

```
cd step-007
stack build
stack exec to-do-exe
```

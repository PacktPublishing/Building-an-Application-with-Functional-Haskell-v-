# Building an Application with Haskell

## 3.3.3 "Parsing and writing YAML"

### Build `step-010`

```
cd step-010
stack build
stack exec to-do-exe
```

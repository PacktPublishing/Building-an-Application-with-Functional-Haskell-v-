# Building an Application with Haskell

## 3.3.1 "File I/O and laziness"

### Build `step-008`

```
cd step-008
stack build
stack exec to-do-exe
```

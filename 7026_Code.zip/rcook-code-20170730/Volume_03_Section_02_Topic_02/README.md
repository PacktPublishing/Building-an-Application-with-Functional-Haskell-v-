# Building an Application with Haskell

## 3.2.2 "ADTs for command-line options"

### Build `step-003`

```
cd step-003
stack build
stack exec to-do-exe
```

### Build `step-004`

```
cd step-004
stack build
stack exec to-do-exe
```

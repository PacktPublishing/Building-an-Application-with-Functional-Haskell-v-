# Building an Application with Haskell

## 3.3.2 "Strings revisited"

### Build `step-009`

```
cd step-009
stack build
stack exec to-do-exe
```

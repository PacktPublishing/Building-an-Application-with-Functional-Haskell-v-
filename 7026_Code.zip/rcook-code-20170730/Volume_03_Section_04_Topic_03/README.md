# Building an Application with Haskell

## 3.4.3 "Deleting items"

### Build `step-015`

```
cd step-015
stack build
stack exec to-do-exe
```

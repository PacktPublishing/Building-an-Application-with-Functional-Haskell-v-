# Building an Application with Haskell

## 3.4.2 "Creating items"

### Build `step-014`

```
cd step-014
stack build
stack exec to-do-exe
```

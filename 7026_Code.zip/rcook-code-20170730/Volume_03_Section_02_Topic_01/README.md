# Building an Application with Haskell

## 3.2.1 "The Applicative Way"

### Build `step-000`

```
cd step-000
stack build
stack exec to-do-exe
```

### Build `step-001`

```
cd step-001
stack build
stack exec to-do-exe
```

### Build `step-002`

```
cd step-002
stack build
stack exec to-do-exe
```

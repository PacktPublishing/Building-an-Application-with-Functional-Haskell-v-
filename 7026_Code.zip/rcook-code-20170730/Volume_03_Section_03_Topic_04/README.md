# Building an Application with Haskell

## 3.3.4 "Other data types"

### Build `step-011`

```
cd step-011
stack build
stack exec to-do-exe
```

### Build `step-012`

```
cd step-012
stack build
stack exec to-do-exe
```
